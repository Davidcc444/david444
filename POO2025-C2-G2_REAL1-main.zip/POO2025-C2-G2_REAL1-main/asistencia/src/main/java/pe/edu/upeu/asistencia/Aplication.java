package pe.edu.upeu.asistencia;

public class Aplication {
    public static void main(String[] args) {
        System.out.println("Hola");
        AsistenciaApplication.main(args);
    }
}
