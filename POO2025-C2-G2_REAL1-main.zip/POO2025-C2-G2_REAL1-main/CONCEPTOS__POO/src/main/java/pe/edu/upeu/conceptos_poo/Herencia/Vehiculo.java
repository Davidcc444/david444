package pe.edu.upeu.Herencia;

public class Vehiculo {
    protected String marca="Ford";

    public void Sonido() {
        System.out.println("Tuuuuuuu");
    }
}
