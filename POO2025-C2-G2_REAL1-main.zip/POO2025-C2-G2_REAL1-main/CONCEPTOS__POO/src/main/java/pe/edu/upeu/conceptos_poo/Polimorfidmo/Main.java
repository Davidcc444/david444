package pe.edu.upeu.Polimorfidmo;

public class Main {
    public static void main(String[] args) {
        Loro l =new Loro();
        l.sonidoAnimal();
    }
}
