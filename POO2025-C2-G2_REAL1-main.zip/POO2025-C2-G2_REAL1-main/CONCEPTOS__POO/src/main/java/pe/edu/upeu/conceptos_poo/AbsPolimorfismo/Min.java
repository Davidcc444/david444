package pe.edu.upeu.AbsPolimorfismo;

public class Min {
    public static void main(String[] args) {
        Loro l =new Loro();
        l.sonidoAnimal();
        l.dornir();
    }
}
