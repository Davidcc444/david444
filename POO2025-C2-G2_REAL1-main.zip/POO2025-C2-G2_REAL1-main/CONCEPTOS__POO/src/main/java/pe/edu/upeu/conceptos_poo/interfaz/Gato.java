package pe.edu.upeu.interfaz;

public class Gato {
}
