package pe.edu.upeu.Polimorfidmo;

public class Loro extends Animal{
    @Override
    void sonidoAnimal() {
        System.out.println("El loro es un animal, soy un loro");
    }
}
