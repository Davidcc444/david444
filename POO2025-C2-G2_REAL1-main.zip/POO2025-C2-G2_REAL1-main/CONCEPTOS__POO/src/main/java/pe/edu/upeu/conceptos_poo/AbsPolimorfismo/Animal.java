package pe.edu.upeu.AbsPolimorfismo;

public abstract class Animal {
    public abstract void sonidoAnimal ();
    public void dornir (){
        System.out.println("ZZZZ zzz");
    }
}
