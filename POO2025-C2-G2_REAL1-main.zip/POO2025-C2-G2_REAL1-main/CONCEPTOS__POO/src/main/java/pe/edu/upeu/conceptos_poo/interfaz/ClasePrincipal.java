package pe.edu.upeu.interfaz;

public class ClasePrincipal {
    public static void main(String[] args) {
        Animal animal=new Loro();
        animal.emitirSonido();
        animal.dormir();
    }
}
