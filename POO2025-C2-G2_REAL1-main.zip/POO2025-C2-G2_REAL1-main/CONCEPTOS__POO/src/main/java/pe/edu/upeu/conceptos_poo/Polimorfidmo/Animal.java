package pe.edu.upeu.Polimorfidmo;

public class Animal {
    void sonidoAnimal(){
        System.out.println("El amimal emite un sonido");
    }
}
