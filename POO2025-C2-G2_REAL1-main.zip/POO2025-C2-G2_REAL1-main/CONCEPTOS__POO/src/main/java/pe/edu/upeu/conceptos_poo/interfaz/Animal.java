package pe.edu.upeu.interfaz;

public interface Animal {
    void emitirSonido();
    void dormir();
}
