package pe.edu.upeu.conceptos_poo.pomodoro;

public class Aplication {
    public static void main(String[] args) {
        System.out.println("Iniciando Pomodoro...");
        PomodoroApplication.main(args);
    }
}
