package pe.edu.upeu.conceptospoo.abspolimorfismo;

public class Main {
    public static void main(String[] args) {
        Loro l = new Loro();
        l.sonidoAnimal();
        l.dormir();
    }
}
