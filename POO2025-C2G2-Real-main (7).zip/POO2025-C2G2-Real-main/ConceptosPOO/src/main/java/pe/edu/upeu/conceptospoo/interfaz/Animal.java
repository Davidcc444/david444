package pe.edu.upeu.conceptospoo.interfaz;

public interface Animal {
    void emitirSonido();

    void dormir();

}
