package pe.edu.upeu.conceptospoo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConceptosPooApplication {

    public static void main(String[] args) {
        SpringApplication.run(ConceptosPooApplication.class, args);
    }

}
