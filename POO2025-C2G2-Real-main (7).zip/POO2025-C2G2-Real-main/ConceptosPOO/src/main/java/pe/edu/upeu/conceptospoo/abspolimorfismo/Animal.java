package pe.edu.upeu.conceptospoo.abspolimorfismo;

public abstract class Animal {
    public abstract void sonidoAnimal();
    public void dormir(){
        System.out.println("Zzz...zzz");
    }
}
