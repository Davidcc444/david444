package pe.edu.upeu.conceptospoo.herencia;

public class Vehiculo {
    protected String marca="Ford";

    public String sonido() {
        return "Tuut...tuut!...";
    }

}
