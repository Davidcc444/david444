package pe.edu.upeu.conceptospoo.polimorfismo;

public class Loro extends Animal{
    void sonidoAnimal(){
        System.out.println("Hey, estoy cambiando..." +
                "soy loro tu amigo fiel");
    }

}
