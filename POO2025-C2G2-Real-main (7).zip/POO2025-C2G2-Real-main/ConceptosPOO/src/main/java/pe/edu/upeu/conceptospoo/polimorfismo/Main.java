package pe.edu.upeu.conceptospoo.polimorfismo;

public class Main {
    public static void main(String[] args) {
        Loro l = new Loro();
        l.sonidoAnimal();
    }
}
