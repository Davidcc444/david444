package pe.edu.upeu.conceptospoo.polimorfismo;

public class Animal {
    void sonidoAnimal(){
        System.out.println("El animal emite algun tipo de sonido");
    }
}
