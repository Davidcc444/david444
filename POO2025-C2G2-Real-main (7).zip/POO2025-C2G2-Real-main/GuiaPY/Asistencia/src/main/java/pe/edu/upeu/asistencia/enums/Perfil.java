package pe.edu.upeu.asistencia.enums;

public enum Perfil {Administrador, Participante, Organizador, Ponente}
